import sqlite3
import datetime as dt
import sys
import requests as req
import pyqtgraph as pg
from PyQt5.QtGui import *
from PyQt5 import uic, Qt
from PyQt5.QtWidgets import QApplication, QPushButton, QWidget, QDialog, QLineEdit
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QVBoxLayout, QMessageBox
from PyQt5.QtCore import QRect
import gettext
import pycountry
import csv
from ast import literal_eval

current_user = ""
current_users_history = []
f = False


# Ниже находится форма для входа пользователя в аккаунт
class Login(QDialog):
    def __init__(self, parent=None):
        # инициализация и структура дизайна
        super(Login, self).__init__(parent)
        self.setWindowTitle("Авторизация")

        self.textName = QLineEdit(self)
        self.textPass = QLineEdit(self)
        self.textName.setPlaceholderText("Логин")
        self.textPass.setPlaceholderText("Пароль")
        self.textPass.setEchoMode(QLineEdit.Password)
        self.buttonLogin = QPushButton('Войти', self)
        self.buttonLogin.clicked.connect(self.handledata)
        self.buttonRegister = QPushButton('Зарегистрироваться', self)
        self.buttonRegister.clicked.connect(self.redirect_reg)
        self.buttonDelogin = QPushButton('Выйти', self)
        self.buttonDelogin.clicked.connect(self.handleDelogin)
        layout = QVBoxLayout(self)
        layout.addWidget(self.textName)
        layout.addWidget(self.textPass)
        layout.addWidget(self.buttonLogin)
        layout.addWidget(self.buttonRegister)
        layout.addWidget(self.buttonDelogin)

    def handledata(self):
        # файл Users.csv - база данных по пользователям, хранящая их логины, пароли и истории запросов (см презу)
        # данная функция проверяет ввёденные пользователем логин и пароль,
        # собирает в словарь данные из csv файла с данными о всех пользователях
        with open('Users.csv', mode='r', encoding='utf-8') as csvfile:
            reader = list(csv.reader(csvfile, delimiter=';', quotechar="'"))
            self.users = {}
            for el in reader:
                if el:
                    self.users[el[0]] = el[1:]
        print(self.users)
        # сопоставление данных
        if (self.textName.text() in self.users and
                self.textPass.text() == self.users[self.textName.text()][0]):
            # глобальные переменные используются для удобной работы с пользовательскими данными
            global current_user
            current_user = self.textName.text()
            global current_users_history
            current_users_history = literal_eval(self.users[self.textName.text()][1])
            global f
            f = True
            self.accept()
        else:
            QMessageBox.warning(self, 'Error', 'Неправильное имя пользователя или пароль')

    # перенаправление на окно регистрации и завершение Формы Входа
    def redirect_reg(self):
        self.window = Register()
        self.window.exec()

    def handleDelogin(self):
        global current_user, current_users_history, f
        current_user = ''
        current_users_history = []
        f = True
        self.accept()


# эта форма отвечает за регистрациию пользователя
class Register(QDialog):
    def __init__(self, parent=None):
        # инициализация
        super(Register, self).__init__(parent)
        self.setWindowTitle("Регистрация")

        self.username = QLineEdit(self)
        self.userpassword = QLineEdit(self)
        self.userpassword_checker = QLineEdit(self)
        self.username.setPlaceholderText("Придумайте логин")
        self.userpassword_checker.setPlaceholderText("Повторите пароль")
        self.userpassword_checker.setEchoMode(QLineEdit.Password)
        self.userpassword.setPlaceholderText("Придумайте пароль")
        self.userpassword.setEchoMode(QLineEdit.Password)
        self.buttonRegister = QPushButton('Зарегистрироваться', self)
        self.buttonRegister.clicked.connect(self.handledata)
        layout = QVBoxLayout(self)
        layout.addWidget(self.username)
        layout.addWidget(self.userpassword)
        layout.addWidget(self.userpassword_checker)
        layout.addWidget(self.buttonRegister)

    # функия ниже отвечает за добавление пользователя в базу данных Users
    def handledata(self):
        # проверяет, что пароль был подтверждён (введены одинаковые данные в строки)
        if self.userpassword.text() == self.userpassword_checker.text():
            # добавляет данные в БД
            with open('Users.csv', mode='a', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_MINIMAL)
                writer.writerow([self.username.text(), self.userpassword.text(), []])
            self.accept()
        else:
            QMessageBox.warning(self, 'Error', 'Пароли не совпадают')


# установка русских названий для стран, относительно их интернационального кода - импорт русских названий
russian = gettext.translation("iso3166", pycountry.LOCALES_DIR, languages=["ru"])
russian.install()


# данная функция переводит код страны в её русское название
def get_country(code):
    rus = pycountry.countries.get(alpha_2=code)
    return _(rus.name)


# представленная функция определяет направление ветра, по введёнм градусам
# данные о направлении ветра передаются в виде кол-ва градусов - азимута
def wind_direction(degrees):
    value = int((degrees / 22.5) + 0.5)
    directions = ["С", "ССВ", "СВ", "ВСВ", "В", "ВЮВ", "ЮВ", "ЮЮВ", "Ю", "ЮЮЗ", "ЮЗ", "ЗЮЗ", "З", "ЗСЗ", "СЗ", "ССЗ"]
    return directions[(value % 16)]


# стандартный ключ для выполнения интерент-запроса
appid = "9d0864cfefebb1ec3592e7379f7776af"
# общий текстовый шрифт
custom_font = QFont('Monttserat', 14)


# эта Форма отвечает за ввод населённого пункта, предосталвет возможность авторизоваться
# она является главной в этом проекте
class CityInputForm(QMainWindow):
    def __init__(self):
        # инициализация
        super().__init__()
        uic.loadUi("WA_inputcity.ui", self)
        self.setWindowTitle("Главная")

        # установление глобальных значений и интерефейс о пользователе, предусмотрена ситуация,
        # когда пользователь не авторизовался
        pixmap = QPixmap('usericon.png')
        self.user_img.setPixmap(pixmap)
        self.user.setFont(custom_font)
        self.user.setText(current_user)

        global current_users_history
        current_users_history = ["История запросов:"] + current_users_history
        self.history.setDuplicatesEnabled(False)
        self.history.setFont(custom_font)
        self.history.addItems(current_users_history)
        self.history.setAutoFillBackground(True)
        self.history.currentIndexChanged.connect(self.handleComboBoxPressed)
        self.history.setStyleSheet("color : rgb(255, 255, 255);"
                                   "background-color : rgb(163, 163, 163)")
        self.user_img.resize(pixmap.width(), pixmap.height())

        # кнопка авторизоваться
        self.authorize.clicked.connect(self.authorization)
        self.authorize.setFont(custom_font)
        self.authorize.setStyleSheet("background-color : rgb(97, 182, 255);")
        # кнопка ввода города
        self.btn.clicked.connect(self.run)
        self.btn.setFont(custom_font)
        self.btn.setStyleSheet("background-color : rgb(97, 182, 255);"
                               "selection-color: white;"
                               )
        # строка ввода города
        self.cityname.setFont(custom_font)
        self.cityname.setPlaceholderText("Введите название населённого пункта")

    # функция отвечает за обновление виджетов
    def locate_user(self):
        self.user.setText(current_user)
        self.history.addItems(current_users_history)

    # обновляет историю запросов
    def handleComboBoxPressed(self):
        if self.history.currentText() != "История запросов:":
            self.cityname.setText(str(self.history.currentText()))

    # данная функция отвечает за авторизацию
    def authorization(self):
        self.login_form = Login()
        self.login_form.exec()
        if self.login_form.finished and f:
            self.locate_user()

    # основная функция, выполняющая пользовательский запрос (населённый пункт)
    def run(self):
        self.city = self.cityname.text()
        self.city = self.city.capitalize()

        # блок кода ниже добавлет в базу данных новый город
        with open('Users.csv', mode='r', encoding='utf-8') as csvfile:
            reader = list(csv.reader(csvfile, delimiter=';', quotechar="'"))
            self.users = {}
            ct = 0
            lst_back = []
            for el in reader:
                if el:
                    if el[0] == current_user:
                        idrow = ct
                    self.users[el[0]] = el[1:]
                    lst_back.append(el)
                    ct += 1
        if current_user:
            new = self.users[current_user]
            x = literal_eval(new[1])
            x.append(self.city)
            new[1] = x
            with open('Users.csv', mode='w', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile, delimiter=';', quoting=csv.QUOTE_MINIMAL)
                for i in range(ct):
                    if i == idrow:
                        writer.writerow([current_user] + new)
                    else:
                        writer.writerow(lst_back[i])

        # ниже выполняется интернте-запрос и трансофрмируется в словарь словарей - удобное предсталвение всех данных
        try:
            response = req.get("http://api.openweathermap.org/data/2.5/weather",
                               params={'q': self.city, 'lang': 'ru', 'units': 'metric',
                                       'APPID': appid})
            # трансофрмация данных в объект Пайтона - словарь словарей
            self.weather = response.json()
            print(self.weather)

            # предусмотрено что пользователей введёт неправильые данные или запрос не выполнится
            # это отображается в словаре с данными weather, параиметром cod
            if self.weather["cod"] != 200:
                self.cityname.setText("Неверно введено название")
            else:
                # открытие следующего окна с текущей погодой
                self.window = TodayForm(self.city, self.weather)
                self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
                self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                          "selection-background-color: white;"
                                          "color: rgb(255,255,255);")
                QApplication.setFont(custom_font, "QLabel")
                QApplication.setFont(custom_font, "QPushButton")
                self.window.setGeometry(100, 100, 1500, 800)
                self.window.show()
                self.close()
        except Exception as e:
            print(e)


# форма ниже отвечает за ТЕКУЩУЮ погоду
class TodayForm(QWidget):
    def __init__(self, city, weather):
        super().__init__()
        # инициализация
        uic.loadUi("WA_showtoday.ui", self)
        self.setWindowTitle("Погода сегодня")

        # установление глобальных значений и интерефейс о пользователе, предусмотрена ситуация,
        # когда пользователь не авторизовался
        pixmap = QPixmap('usericon.png')
        self.user.setText(current_user)
        self.user_img.setPixmap(pixmap)
        self.user_img.resize(pixmap.width(), pixmap.height())
        self.horizontalLayout.setGeometry(QRect(0, 0, 1400, 700))
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                )
        self.forward.clicked.connect(self.go_forward)
        self.forward.setStyleSheet("background-color : rgb(97, 182, 255);"
                                   )

        self.city = city
        self.weather = weather

        # в зависимости о данных о состоянии погоды отображаются разные иконки погоды,
        # например, если в Москве солнечно, то покажется картинка с солнцем, а
        # если в санкт-Петербурге идёт снег, то покажется обачко со снежинками
        try:
            img_param = self.weather["weather"][0]["main"]
            cntr = get_country(self.weather["sys"]["country"])
            self.cityinfo.setText(f'''Погода в городе {self.city}, {cntr},
{str(dt.datetime.utcfromtimestamp(weather["dt"]).strftime('%Y-%m-%d %H:%M'))}:''')
            try:
                if img_param == "Clouds":
                    pixmap = QPixmap('clouds.jpg')
                elif img_param == "Clear":
                    pixmap = QPixmap('clear.jpg')
                elif img_param == "Rain" or img_param == "Drizzle":
                    pixmap = QPixmap('rain.jpg')
                elif img_param == "Thunderstorm":
                    pixmap = QPixmap('thunderstorm.jpg')
                elif img_param == "Snow":
                    pixmap = QPixmap('snow.jpg')
                elif img_param == "Snow":
                    pixmap = QPixmap('snow.jpg')
                elif img_param == "Atmosphere":
                    pixmap = QPixmap('atm.jpg')
                else:
                    pixmap = QPixmap('clear_tmp.jpg')
                self.image.setPixmap(pixmap)
                self.image.resize(pixmap.width(), pixmap.height())
            except Exception as ex:
                print(ex)
            try:
                # блок кода ниже отвечает за "большИе строки" - главную информацию о погоде
                self.temperature.show()
                self.temperature.setFont(QFont('Monttserat', 17))
                self.temperature.setText(f'''{str(round(self.weather["main"]["temp"], 1))}°C,
{self.weather["weather"][0]["description"]}, по ощущениям: {str(round(self.weather["main"]["feels_like"]))}°C''')
            except KeyError:
                self.temperature.setText("--°C")

            # ниже представлены другие, менее важные данные
            # предусмотрена ситуация неверного запроса от пользователя, тогда программа ничего не выведет,
            # вместо того, чтобы сломаться
            try:
                self.humidity.show()
                self.humidity.setText(f'Влажность: {str(self.weather["main"]["humidity"])}%')
            except KeyError:
                self.humidity.setText("Влажность: --%")
            try:
                self.visibility.show()
                self.visibility.setText(f'Видимость: {str(self.weather["visibility"])}м')
            except KeyError:
                self.visibility.setText("Видимость: --км")
            try:
                self.pressure.show()
                self.pressure.setText(f'Давление: {str(round(self.weather["main"]["pressure"] * 0.75))}мм.рт.ст')
            except KeyError:
                self.pressure.text_pressure.setText("давление -- ")

            try:
                self.wind.show()
                self.wind.setText(
                    f'Ветер: {str(wind_direction(int(self.weather["wind"]["deg"])))} {str(self.weather["wind"]["speed"])}м/с')
            except KeyError:
                self.wind.setText("Ветер -- м/с")
        except BaseException:
            pass

    # кнопка Назад
    def go_back(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    # кнопка перевода на слоедующее окно - прогноз погоды
    def go_forward(self):
        self.window = Forecast8daysForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


# Форма ниже отвечает за прогноз погоды
class Forecast8daysForm(QWidget):
    def __init__(self, city, weather):
        super().__init__()
        # инициализация
        uic.loadUi("WA_show8days.ui", self)
        self.setWindowTitle("Прогноз погоды")

        # установление глобальных значений и интерефейс отн. пользователя, предусмотрена ситуация,
        # когда пользователь не авторизовался
        pixmap = QPixmap('usericon.png')
        self.user.setText(current_user)
        self.user_img.setPixmap(pixmap)
        self.user_img.resize(pixmap.width(), pixmap.height())
        self.city = city
        self.data = []
        self.weather = weather
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                )
        self.forward.clicked.connect(self.go_forward)
        self.forward.setStyleSheet("background-color : rgb(97, 182, 255);"
                                   )
        self.home.clicked.connect(self.go_home)
        self.home.setStyleSheet("background-color : rgb(97, 182, 255);"
                                )

        self.tableWidget.setStyleSheet(
            "background-color : rgb(97, 182, 255);"
                                       )

        # блок кода ниже выполняет интерент-запрос для прогноза погоды на след. 5 дней
        q = []
        try:
            res = req.get("http://api.openweathermap.org/data/2.5/forecast",
                          params={'q': self.city, 'units': 'metric', 'lang': 'ru', 'APPID': appid})

            # преобразует полученныe данныe в читаемый Пайтоном вид
            data = res.json()

            # структурирует данные в матрицу, для удобства использования
            self.data_wa8days = []
            for el in data['list']:
                date = el['dt_txt'].split()
                x = [date[0], date[1], el['main']['temp_min'], el['weather'][0]['description'],
                     el['main']['pressure'], el['main']['humidity'], el['wind']['speed']]
                self.data_wa8days.append(x)
                q.append(x)

            # в БД Weather_Data_previous_week.sqlite3 (см. презу) в таблице weather представлены
            # значения из матрицы, их можно оттуда брать, для использования за рамками приложения.
            # эти данные не отличаются от предсталвенных в Виджете-таблице, вы можете в этом сами убедиться
            con = sqlite3.connect("Weather_Data_previous_week.sqlite3")
            cur = con.cursor()
            # у таблицы константное имя, поэтому каждый раз необходимо создавать новую, со свежими данными
            cur.execute(f"""DROP TABLE IF EXISTS weather;""")
            cur.execute(f"""CREATE TABLE weather('date', 'time', 'temperature',
'weather', 'pressure', 'humidity', 'wind_speed')""")
            for i in range(len(self.data_wa8days)):
                cur.execute(f"""INSERT INTO weather('date', 'time', 'temperature',
    'weather', 'pressure', 'humidity', 'wind_speed') VALUES{tuple(self.data_wa8days[i])}""")
            res = cur.execute("SELECT * FROM weather").fetchall()
        except Exception as e:
            print("Exception (forecast):", e)
            pass

        # построение таблицы и вывод матрицы с данными в tableWidget
        self.data = q
        title = ['День', 'Время', 'Температура', 'Погодные условия',
                 'Давление', 'Влажность', 'Скорость ветра']
        self.tableWidget.setColumnCount(len(title))
        self.tableWidget.setHorizontalHeaderLabels(title)
        self.tableWidget.setRowCount(0)
        for i, row in enumerate(self.data):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))
        for i in range(len(title)):
            item1 = self.tableWidget.horizontalHeaderItem(i)
            item1.setForeground(QColor(0, 0, 0))
        self.tableWidget.resizeColumnsToContents()

    # кнопки перехода между страницами
    def go_back(self):
        self.window = TodayForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_forward(self):
        self.window = Forecast8days_statsForm(self.city, self.weather, self.data)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);"
                                  'font-size: 18px;')
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_home(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


# Следующая форма, последняя соответственно, отвечает за статистику по прогнозу, предаврительно
class Forecast8days_statsForm(QWidget):
    def __init__(self, city, weather, data):
        super().__init__()
        # инициализация
        uic.loadUi("WA_show8days_stats.ui", self)
        self.setWindowTitle("Статистика погоды по даннам прогноза")

        # установление глобальных значений и интерефейс отн. пользователя, предусмотрена ситуация,
        # когда пользователь не авторизовался
        self.back.clicked.connect(self.go_back)
        self.back.setStyleSheet("background-color : rgb(97, 182, 255);"
                                )
        self.home.clicked.connect(self.go_home)
        self.home.setStyleSheet("background-color : rgb(97, 182, 255);"
                                )

        # пользователь не должен взаимодействовать с данными, кроме графика
        try:
            self.city = city
            self.weather = weather
            self.data = data
            self.temp_max.setReadOnly(True)
            self.temp_max_date.setReadOnly(True)
            self.temp_min.setReadOnly(True)
            self.temp_min_date.setReadOnly(True)
            self.average_temp.setReadOnly(True)
            self.average_hum.setReadOnly(True)
            self.average_pres.setReadOnly(True)
            self.weather_conds.setReadOnly(True)
            self.wind_conds.setReadOnly(True)

            # считает все значения
            mat = -100
            avt = avh = avp = w = ct = 0
            mit = 100
            mitd = matd = wth = ''
            week = self.data[0][0] + '--' + self.data[-1][0]
            q = {}
            graph_temp = []
            graph_dates = []
            for i in range(len(self.data)):
                ct += 1
                graph_temp.append(round(self.data[i][2], 1))
                graph_dates.append(" ".join([self.data[i][0], self.data[i][1]]))
                avt += float(self.data[i][2])
                avh += float(self.data[i][5])
                avp += float(self.data[i][4])
                if float(self.data[i][2]) > mat:
                    mat = float(self.data[i][2])
                    matd = self.data[i][0]
                if float(self.data[i][2]) < mit:
                    mit = float(self.data[i][2])
                    mitd = self.data[i][0]
                if float(self.data[i][6]) > w:
                    w = float(self.data[i][6])
                if self.data[i][3] not in q:
                    q[self.data[i][3]] = 1
                else:
                    q[self.data[i][3]] += 1
            sup = 0
            for key, el in q.items():
                if el > sup:
                    wth = key
                    sup = el

            # выставляет все значения
            self.temp_max.setText(str(round(mat, 1)))
            self.temp_min.setText(str(round(mit, 1)))
            self.temp_max_date.setText(str(matd))
            self.temp_min_date.setText(str(mitd))
            self.average_temp.setText(str(round(avt / ct, 1)))
            self.average_hum.setText(str(round(avh / ct, 1)))
            self.average_pres.setText(str(round(avp / ct, 1)))
            self.weather_conds.setText(str(wth))
            self.wind_conds.setText(str(round(w, 1)))
            #  График:
            graph_dates = dict(enumerate(graph_dates))  # создание словаря - основы графика

            # оси графика нестандартны: datetime.time\float
            stringaxis = pg.AxisItem(orientation='bottom')
            stringaxis.setTicks([graph_dates.items()])

            # легенда графика
            self.GraphWidget.addLegend()

            # ось  состоит из строк - преобразованные объекты даты
            self.GraphWidget.setAxisItems({'bottom': stringaxis})

            # сам график
            self.GraphWidget.plot(list(graph_dates.keys()), graph_temp, brush=QColor(0, 0, 0),
                                  name="Ожидаемая температура", symbol='o', symbolPen=QColor(255, 255, 255),
                                  symbolBrush=0.08)

            #  дизайн графика
            self.GraphWidget.addLine(y=round(avt / ct, 1))  # линия по ординате средней температуры
            self.GraphWidget.setBackground(QColor(255, 255, 255))
            self.GraphWidget.setStyleSheet("border : 5px solid rgb(97, 182, 255);"
                                           "color: rgb(255,255,255);")
        except Exception as e:
            print(e)

    # кнопки
    def go_back(self):
        self.window = Forecast8daysForm(self.city, self.weather)
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()

    def go_home(self):
        self.window = CityInputForm()
        self.window.setAttribute(Qt.Qt.WA_StyledBackground, True)
        self.window.setStyleSheet("background-color: rgb(85, 122, 240);"
                                  "color: rgb(255,255,255);")
        self.window.setGeometry(100, 100, 1500, 800)
        self.window.show()
        self.close()


# запуск приложения
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = CityInputForm()
    ex.show()
    ex.setAttribute(Qt.Qt.WA_StyledBackground, True)

    # дизайн первой страницы
    ex.setStyleSheet("background-color: rgb(85, 122, 240);"
                     "color: rgb(255,255,255);")
    ex.setGeometry(100, 100, 1500, 800)
    sys.exit(app.exec())

# Фактическая информация:
# основные функции:
# текущая погода
# прогноз погоды
# статистика по прогнозу
# авторизация и история запросов
# базы данных:
# sqlite3 файл с данными по прогнозу погоде;
# csv файл с информацией о пользователях
# дизайн с помощью QTDesigner


# спасибо за внимание!)
